Voor het maken van veranderingen zijn er een paar simpele eisen:

1. Zorg er bij het maken van een pull request voor dat je veranderingen zich houden aan het formaat van de rest van de te veranderen pagina.
1. Afbeeldingen moeten in webp formaat, dus niet png of jpg, en pas aub. het formaat aan naar het formaat op de website, dus geen 8k plaatjes ed.
