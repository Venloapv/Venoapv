# Content creëren op Tedeapolis

## Introductie

Dit document is opgesteld om wat duidelijkheid te bieden wat betreft het creëren van content op Tedeapolis. Het is uiteraard toegestaan om content te creëren op Tedeapolis, echter zijn hier wel regels aan verbonden. Deze regels gelden voor elke speler die content wilt creëren en niet enkel voor de content creators zoals aangewezen in de Tedeapolis discord.

## Regels

1. Het is verplicht dat als je live bent, en je deelneemt aan een Discord chat als overheidsdienst, dat je een rood balletje voor jouw naam zet: `:red_circle:`
2. Zorg ervoor dat de mensen met wie je in Discord zit afweten van het feit dat je content creëert.
3. Je bent als content creator een visite kaartje voor Tedeapolis. Mochten er dingen gebeuren, laat het ons weten.
4. Doordat je jezelf vrij makkelijk in de picture zet, kunnen wij wat strenger zijn tegen streamers aangezien we live beelden van ze hebben.
5. Mocht je iets zien bij een andere content creator wat je niet bevalt. Spreek dan een stafflid aan.
6. FailRP, RDM, VDM en dat soort zaken On-Stream (ook off-stream natuurlijk) wordt direct bestraft.
7. De naam Tedeapolis moet in de titel van de video's of livestreams staan zodat het ook door ons gevonden kan worden.
8. Het is niet toegestaan voor content creators vanuit overheidsdiensten om discord porto te laten horen op video's of livestreams.
9. Het is niet toegestaan om deepwebkanalen, telefoonnummers of andere inhoudelijke informatie van telefoons te tonen in video's.
10. Tijdens een livestream is het verplicht om gebruik te maken van streamermodus. Hiermee wordt informatie zoals vernoemd in lid 10 verborgen.  

## Sancties

* Bij het tonen van inhoudelijke informatie op de telefoon (nummers, deepwebkanalen, e.d.) zal er bij de eerste overtreding een straf van de 1e categorie uitgeschreven worden. Bij herhaaldelijke overtreding zal ter beoordeling van een stafflid de straf verhoogd kunnen worden.
* Wanneer tijdens een livestream geen gebruik wordt gemaakt van de streamermodus zal een straf van de 2e categorie volgen. Bij herhaaldelijke overtreding zal ter beoordeling van een stafflid de straf verhoogd kunnen worden.
